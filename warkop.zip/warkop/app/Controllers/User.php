<?php

namespace App\Controllers;

use App\Models\MenuModel;
use App\Models\OrderModel;

class User extends BaseController
{
   
    public function dashboard()
    {
        $menuModel = new MenuModel();
        $orderModel = new OrderModel();

        $menus = $menuModel->findAll();

       
        $orders = $orderModel->select('orders.*, menus.name as menu_name')
            ->join('menus', 'menus.id = orders.menu_id')
            ->where('orders.user_id', session('user_id'))
            ->orderBy('orders.created_at', 'DESC')
            ->findAll();

        return view('user/dashboard', [
            'menus' => $menus,
            'orders' => $orders
        ]);
    }


    public function order()
    {
        $orderModel = new OrderModel();

        $data = [
            'user_id' => session('user_id'),
            'menu_id' => $this->request->getPost('menu_id'),
            'quantity' => $this->request->getPost('quantity'),
            'note' => $this->request->getPost('note'),
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];

        $orderModel->insert($data);

        session()->setFlashdata('success', 'Pesanan berhasil dikirim!');
        return redirect()->to('/user/dashboard');
    }
}