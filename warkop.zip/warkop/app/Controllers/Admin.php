<?php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\MenuModel;
use App\Models\UserModel;

class Admin extends BaseController
{
    public function dashboard()
    {
        $orderModel = new OrderModel();
        $menuModel = new MenuModel();
        $userModel = new UserModel();

        $totalOrders = $orderModel->countAll();
        $totalMenus = $menuModel->countAll();
        $totalUsers = $userModel->where('role', 'user')->countAllResults();

        return view('admin/dashboard', [
            'totalOrders' => $totalOrders,
            'totalMenus' => $totalMenus,
            'totalUsers' => $totalUsers
        ]);
    }

    public function orders()
    {
        $orderModel = new OrderModel();

        $orders = $orderModel
            ->select('orders.*, users.name as user_name, menus.name as menu_name')
            ->join('users', 'users.id = orders.user_id')
            ->join('menus', 'menus.id = orders.menu_id')
            ->orderBy('orders.created_at', 'DESC')
            ->findAll();

        return view('admin/orders', [
            'orders' => $orders
        ]);
    }

    public function confirmOrder($id)
    {
        $orderModel = new OrderModel();

        $order = $orderModel->find($id);
        if ($order) {
            $orderModel->update($id, ['status' => 'confirmed']);
            session()->setFlashdata('success', 'Pesanan telah dikonfirmasi.');
        } else {
            session()->setFlashdata('error', 'Pesanan tidak ditemukan.');
        }

        return redirect()->to('/admin/orders');
    }
}