<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <title>Kelola Pesanan - Cafe Kopi</title>
 <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>

<body>

 <header>
  <h1>Kelola Pesanan</h1>
  <nav>
   <a href="<?= base_url('/admin/dashboard') ?>">Dashboard</a>
   <a href="<?= base_url('/logout') ?>">Logout</a>
  </nav>
 </header>

 <div class="container">
  <h2>Daftar Pesanan</h2>

  <?php if(session()->getFlashdata('success')): ?>
  <div class="alert"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <?php foreach ($orders as $order): ?>
  <div style="margin-bottom: 20px; border-bottom: 1px solid #ccc; padding-bottom: 10px;">
   <p><strong>User:</strong> <?= esc($order['user_name']) ?></p>
   <p><strong>Menu:</strong> <?= esc($order['menu_name']) ?></p>
   <p><strong>Jumlah:</strong> <?= $order['quantity'] ?></p>
   <p><strong>Catatan:</strong> <?= esc($order['note']) ?></p>
   <p><strong>Status:</strong> <?= $order['status'] ?></p>

   <?php if($order['status'] === 'pending'): ?>
   <form action="<?= base_url('/admin/orders/confirm/'.$order['id']) ?>" method="post">
    <button type="submit">Konfirmasi</button>
   </form>
   <?php else: ?>
   <p style="color: green;">✅ Sudah dikonfirmasi</p>
   <?php endif; ?>
  </div>
  <?php endforeach; ?>
 </div>

</body>

</html>