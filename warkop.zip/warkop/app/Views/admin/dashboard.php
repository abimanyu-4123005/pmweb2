<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <title>Dashboard Admin - Cafe Kopi</title>
 <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>

<body>

 <header>
  <h1>Dashboard Admin</h1>
  <nav>
   <a href="<?= base_url('/admin/orders') ?>">Pesanan</a>
   <a href="<?= base_url('/logout') ?>">Logout</a>
  </nav>
 </header>

 <div class="container">
  <h2>Halo, <?= session('user_name') ?> 👋</h2>
  <p>Gunakan menu di atas untuk mengelola pesanan.</p>
 </div>

</body>

</html>