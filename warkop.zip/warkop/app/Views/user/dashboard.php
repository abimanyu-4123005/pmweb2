<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <title>Dashboard User - Cafe Kopi</title>
 <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>

<body>

 <header>
  <h1>Selamat Datang, <?= session('user_name') ?></h1>
  <nav>
   <a href="<?= base_url('/logout') ?>">Logout</a>
  </nav>
 </header>

 <div class="container">
  <h2>Menu Kopi</h2>

  <?php if(session()->getFlashdata('success')): ?>
  <div class="alert"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <?php foreach ($menus as $menu): ?>
  <form action="<?= base_url('/user/order') ?>" method="post">
   <h3><?= esc($menu['name']) ?> - Rp <?= number_format($menu['price'], 0, ',', '.') ?></h3>
   <p><?= esc($menu['description']) ?></p>
   <input type="hidden" name="menu_id" value="<?= $menu['id'] ?>">
   <input type="number" name="quantity" placeholder="Jumlah" required min="1">
   <textarea name="note" placeholder="Catatan (opsional)"></textarea>
   <button type="submit">Pesan</button>
   <hr><br>
  </form>
  <?php endforeach; ?>
 </div>

 <div class="order-history">
  <h2>Riwayat Pesanan Anda</h2>

  <?php if (empty($orders)): ?>
  <p>Belum ada pesanan.</p>
  <?php else: ?>
  <?php foreach ($orders as $order): ?>
  <div class="order-card">
   <p><strong>Menu:</strong> <?= esc($order['menu_name']) ?></p>
   <p><strong>Jumlah:</strong> <?= $order['quantity'] ?></p>
   <p><strong>Catatan:</strong> <?= esc($order['note']) ?: '-' ?></p>
   <p><strong>Status:</strong>
    <span class="order-status <?= $order['status'] ?>">
     <?= $order['status'] === 'confirmed' ? 'Dikonfirmasi' : 'Menunggu' ?>
    </span>
   </p>
   <p><strong>Tanggal:</strong> <?= date('d-m-Y H:i', strtotime($order['created_at'])) ?></p>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>
 </div>


</body>

</html>