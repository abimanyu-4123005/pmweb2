<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <title>Cafe Kopi</title>
 <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>

<body>

 <header>
  <h1>Cafe Kopi</h1>
  <nav>
   <a href="<?= base_url('/login') ?>">Login</a>
   <a href="<?= base_url('/register') ?>">Register</a>
  </nav>
 </header>

 <div class="container">
  <h2>Selamat Datang di Cafe Kopi</h2>
  <p>Kami menyediakan berbagai jenis kopi khas Indonesia yang siap menemani harimu.
   Nikmati suasana santai sambil menikmati secangkir kopi hangat.</p>
 </div>

</body>

</html>