<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
 <title>Login - Cafe Kopi</title>
 <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>

<body>

 <header>
  <h1>Login</h1>
  <nav>
   <a href="<?= base_url('/') ?>">Home</a>
   <a href="<?= base_url('/register') ?>">Register</a>
  </nav>
 </header>

 <div class="container">
  <h2>Masuk Akun Anda</h2>
  <form action="<?= base_url('/login') ?>" method="post">
   <input type="email" name="email" placeholder="Email" required>
   <input type="password" name="password" placeholder="Password" required>
   <button type="submit">Login</button>
  </form>
 </div>

</body>

</html>